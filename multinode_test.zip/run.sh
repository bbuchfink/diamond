#!/bin/bash

set -e
set -x

rm -f ./libworkstack/* diamond-tmp-* *.tmp

FLAGS="blastp --block-size 0.0015 --threads 1 --db astral.dmnd --query astral-scopedom-seqres-gd-sel-gs-bib-40-2.07.fasta --verbose --tmpdir `pwd`"

# sequential run
FLAGS="$FLAGS --out astral_seq.m8"
PROCS="0"

# enable for parallelism with two processes
#FLAGS="$FLAGS --multiprocessing --out astral_mp.m8"
#PROCS="0 1"

for I in $PROCS
do

#/ltmp/tmp/diamond_build_2nd
/usr/bin/env SLURM_PROCID=${I} ./diamond $FLAGS &>run_${I}.log &

done


wait

